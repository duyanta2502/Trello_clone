import Board from './pages/Boards/_id'

function App() {
  return (
    <>
      <Board />
    </>
  )
}

export default App
